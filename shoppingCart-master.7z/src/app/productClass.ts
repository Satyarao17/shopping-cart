export class Product {
    id:number;
    name: string;
    color:string;
    description: string;
    price: number;
    photoPath:string;
}
